﻿namespace Models
{
    public static class Constantes
    {
 
    }
}
